# Orinboy Hotdog Telegram Bot

## Files
- `main.py` — Telegram bot code (Uzbek/Russian, delivery-only, cart, checkout, admin order status)
- `requirements.txt` — Python dependency
- `render.yaml` — Render background worker configuration
- `.gitignore` — avoids uploading secrets and local database

## Deploy to Render
1. Upload these files to a GitHub repository.
2. In Render, create a **Background Worker** from that repository (or use the Blueprint flow).
3. Add environment variables:
   - `BOT_TOKEN`: token from BotFather
   - `ADMIN_IDS`: numeric Telegram user IDs separated by commas, e.g. `123456789,987654321`
4. Deploy and check logs.

## Security
Never upload your bot token or `.env` file to GitHub.

## Important limitations
This starter uses SQLite. On Render, local files may not persist across restarts/redeploys unless persistent storage is configured. For reliable long-term order storage, use a persistent disk or managed database.
