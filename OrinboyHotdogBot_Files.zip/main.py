import os
import sqlite3
import logging
from datetime import datetime
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
    ReplyKeyboardMarkup, KeyboardButton
)
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, ContextTypes, filters
)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logging.getLogger("httpx").setLevel(logging.WARNING)

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_IDS = {
    int(value.strip())
    for value in os.getenv("ADMIN_IDS", "").split(",")
    if value.strip().isdigit()
}
DB_PATH = os.getenv("DB_PATH", "orinboy_orders.db")

PRODUCTS = {
    "classic": {"uz": "Klassik hot-dog", "ru": "Классический хот-дог", "price": 28000, "emoji": "🌭"},
    "cheese": {"uz": "Pishloqli hot-dog", "ru": "Хот-дог с сыром", "price": 32000, "emoji": "🧀"},
    "double": {"uz": "Double hot-dog", "ru": "Двойной хот-дог", "price": 40000, "emoji": "🌭"},
    "fries": {"uz": "Kartoshka fri", "ru": "Картофель фри", "price": 18000, "emoji": "🍟"},
    "cola": {"uz": "Cola", "ru": "Кола", "price": 12000, "emoji": "🥤"},
}
TEXT = {
    "uz": {
        "welcome": "🌭 Orinboy Hotdog botiga xush kelibsiz!\nTilni tanlang:",
        "menu": "🍽 Menyu. Mahsulotni tanlang:",
        "cart_empty": "Savatingiz hozircha bo‘sh.",
        "cart": "🛒 Savatingiz:",
        "added": "Savatchaga qo‘shildi ✅",
        "checkout": "Buyurtmani rasmiylashtirish",
        "clear": "Savatchani tozalash",
        "back": "⬅️ Menyu",
        "ask_name": "Ism-familiyangizni yozing:",
        "ask_phone": "Telefon raqamingizni yuboring:",
        "ask_address": "Yetkazib berish manzilini yozing (mo‘ljal bilan):",
        "ask_payment": "To‘lov turini tanlang:",
        "cash": "💵 Kuryerga naqd",
        "card": "💳 Kuryerga karta orqali",
        "order_done": "✅ Buyurtmangiz qabul qilindi! Buyurtma raqami: #{order_id}\nHolatini bot orqali yuboramiz.",
        "cancelled": "Amal bekor qilindi. /start orqali qayta boshlang.",
        "status": "Buyurtma #{order_id} holati: {status}",
        "not_admin": "Bu buyruq faqat administratorlar uchun.",
        "no_orders": "Hozircha buyurtmalar yo‘q.",
        "orders_title": "📋 Oxirgi buyurtmalar:",
        "status_new": "Yangi",
        "status_cooking": "Tayyorlanmoqda",
        "status_delivery": "Kuryerga berildi",
        "status_done": "Yetkazildi",
        "status_cancel": "Bekor qilindi",
        "status_updated": "Buyurtma holati yangilandi.",
    },
    "ru": {
        "welcome": "🌭 Добро пожаловать в Orinboy Hotdog!\nВыберите язык:",
        "menu": "🍽 Меню. Выберите товар:",
        "cart_empty": "Ваша корзина пока пуста.",
        "cart": "🛒 Ваша корзина:",
        "added": "Добавлено в корзину ✅",
        "checkout": "Оформить заказ",
        "clear": "Очистить корзину",
        "back": "⬅️ Меню",
        "ask_name": "Введите имя и фамилию:",
        "ask_phone": "Отправьте номер телефона:",
        "ask_address": "Введите адрес доставки и ориентир:",
        "ask_payment": "Выберите способ оплаты:",
        "cash": "💵 Наличными курьеру",
        "card": "💳 Картой курьеру",
        "order_done": "✅ Заказ принят! Номер заказа: #{order_id}\nСтатус отправим в этот бот.",
        "cancelled": "Действие отменено. Начните заново через /start.",
        "status": "Статус заказа #{order_id}: {status}",
        "not_admin": "Эта команда доступна только администраторам.",
        "no_orders": "Заказов пока нет.",
        "orders_title": "📋 Последние заказы:",
        "status_new": "Новый",
        "status_cooking": "Готовится",
        "status_delivery": "Передан курьеру",
        "status_done": "Доставлен",
        "status_cancel": "Отменён",
        "status_updated": "Статус заказа обновлён.",
    }
}
LANG_BUTTONS = {"uz": "🇺🇿 O‘zbekcha", "ru": "🇷🇺 Русский"}
STATUS_KEYS = ["new", "cooking", "delivery", "done", "cancel"]


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                customer_name TEXT NOT NULL,
                phone TEXT NOT NULL,
                address TEXT NOT NULL,
                payment TEXT NOT NULL,
                items TEXT NOT NULL,
                total INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'new',
                created_at TEXT NOT NULL
            )
        """)


def lang_of(context):
    return context.user_data.get("lang", "uz")


def tr(lang, key):
    return TEXT.get(lang, TEXT["uz"]).get(key, TEXT["uz"].get(key, key))


def is_admin(user_id):
    return user_id in ADMIN_IDS


def money(amount):
    return f"{amount:,}".replace(",", " ") + " so‘m"


def menu_keyboard(lang):
    rows = []
    for key, product in PRODUCTS.items():
        rows.append([InlineKeyboardButton(
            f'{product["emoji"]} {product[lang]} — {money(product["price"])}',
            callback_data=f"add:{key}"
        )])
    rows.append([
        InlineKeyboardButton("🛒 Savat" if lang == "uz" else "🛒 Корзина", callback_data="cart"),
        InlineKeyboardButton("🌐 Til / Язык", callback_data="language")
    ])
    return InlineKeyboardMarkup(rows)


def language_keyboard():
    return InlineKeyboardMarkup([[
        InlineKeyboardButton(LANG_BUTTONS["uz"], callback_data="lang:uz"),
        InlineKeyboardButton(LANG_BUTTONS["ru"], callback_data="lang:ru")
    ]])


def cart_total(cart):
    return sum(PRODUCTS[k]["price"] * qty for k, qty in cart.items())


def cart_text(cart, lang):
    if not cart:
        return tr(lang, "cart_empty")
    lines = [tr(lang, "cart")]
    for key, qty in cart.items():
        p = PRODUCTS[key]
        lines.append(f'{p["emoji"]} {p[lang]} × {qty} — {money(p["price"] * qty)}')
    lines.append(f'\n💰 Jami: {money(cart_total(cart))}' if lang == "uz" else f'\n💰 Итого: {money(cart_total(cart))}')
    return "\n".join(lines)


def cart_keyboard(lang, cart):
    rows = []
    if cart:
        rows.append([InlineKeyboardButton(tr(lang, "checkout"), callback_data="checkout")])
        rows.append([InlineKeyboardButton(tr(lang, "clear"), callback_data="clear_cart")])
    rows.append([InlineKeyboardButton(tr(lang, "back"), callback_data="menu")])
    return InlineKeyboardMarkup(rows)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.setdefault("cart", {})
    await update.message.reply_text(tr(lang_of(context), "welcome"), reply_markup=language_keyboard())


async def show_menu(update_or_query, context):
    lang = lang_of(context)
    if hasattr(update_or_query, "edit_message_text"):
        await update_or_query.edit_message_text(tr(lang, "menu"), reply_markup=menu_keyboard(lang))
    else:
        await update_or_query.message.reply_text(tr(lang, "menu"), reply_markup=menu_keyboard(lang))


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("checkout_step", None)
    context.user_data.pop("checkout", None)
    await update.message.reply_text(tr(lang_of(context), "cancelled"))


async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data or ""
    user_id = query.from_user.id
    lang = lang_of(context)

    if data.startswith("status:") and not is_admin(user_id):
        await query.answer(tr(lang, "not_admin"), show_alert=True)
        return

    await query.answer()

    if data.startswith("lang:"):
        context.user_data["lang"] = data.split(":", 1)[1]
        lang = lang_of(context)
        await query.edit_message_text(tr(lang, "menu"), reply_markup=menu_keyboard(lang))
        return
    if data == "language":
        await query.edit_message_text(tr(lang, "welcome"), reply_markup=language_keyboard())
        return
    if data == "menu":
        await query.edit_message_text(tr(lang, "menu"), reply_markup=menu_keyboard(lang))
        return
    if data.startswith("add:"):
        key = data.split(":", 1)[1]
        if key not in PRODUCTS:
            return
        cart = context.user_data.setdefault("cart", {})
        cart[key] = cart.get(key, 0) + 1
        await query.message.reply_text(tr(lang, "added"))
        return
    if data == "cart":
        cart = context.user_data.setdefault("cart", {})
        await query.edit_message_text(cart_text(cart, lang), reply_markup=cart_keyboard(lang, cart))
        return
    if data == "clear_cart":
        context.user_data["cart"] = {}
        await query.edit_message_text(tr(lang, "cart_empty"), reply_markup=cart_keyboard(lang, {}))
        return
    if data == "checkout":
        cart = context.user_data.setdefault("cart", {})
        if not cart:
            await query.edit_message_text(tr(lang, "cart_empty"), reply_markup=cart_keyboard(lang, cart))
            return
        context.user_data["checkout"] = {}
        context.user_data["checkout_step"] = "name"
        await query.message.reply_text(tr(lang, "ask_name"))
        return
    if data.startswith("payment:"):
        payment = data.split(":", 1)[1]
        checkout_data = context.user_data.get("checkout", {})
        cart = context.user_data.get("cart", {})
        if not cart or not checkout_data:
            await query.message.reply_text(tr(lang, "cancelled"))
            return
        checkout_data["payment"] = payment
        items = []
        for key, qty in cart.items():
            p = PRODUCTS[key]
            items.append(f'{p["name"] if "name" in p else p[lang]} x{qty}')
        items_text = "; ".join(items)
        total = cart_total(cart)
        with db() as conn:
            cur = conn.execute("""
                INSERT INTO orders (user_id, customer_name, phone, address, payment, items, total, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'new', ?)
            """, (
                user_id, checkout_data["name"], checkout_data["phone"],
                checkout_data["address"], payment, items_text, total,
                datetime.now().isoformat(timespec="seconds")
            ))
            order_id = cur.lastrowid
        context.user_data["cart"] = {}
        context.user_data.pop("checkout_step", None)
        context.user_data.pop("checkout", None)
        await query.message.reply_text(tr(lang, "order_done").format(order_id=order_id))
        admin_text = (
            f"🆕 Buyurtma #{order_id}\n"
            f"👤 {checkout_data['name']}\n"
            f"📞 {checkout_data['phone']}\n"
            f"📍 {checkout_data['address']}\n"
            f"💳 {payment}\n"
            f"🍽 {items_text}\n"
            f"💰 {money(total)}"
        )
        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("👨‍🍳 Tayyorlanmoqda", callback_data=f"status:{order_id}:cooking"),
            InlineKeyboardButton("🛵 Kuryerga berildi", callback_data=f"status:{order_id}:delivery")
        ], [
            InlineKeyboardButton("✅ Yetkazildi", callback_data=f"status:{order_id}:done"),
            InlineKeyboardButton("❌ Bekor qilish", callback_data=f"status:{order_id}:cancel")
        ]])
        for admin_id in ADMIN_IDS:
            try:
                await context.bot.send_message(admin_id, admin_text, reply_markup=keyboard)
            except Exception:
                logging.exception("Admin notification failed")
        return
    if data.startswith("status:"):
        _, order_id, new_status = data.split(":", 2)
        if new_status not in STATUS_KEYS:
            return
        with db() as conn:
            row = conn.execute("SELECT user_id FROM orders WHERE id = ?", (int(order_id),)).fetchone()
            if not row:
                return
            conn.execute("UPDATE orders SET status = ? WHERE id = ?", (new_status, int(order_id)))
        customer_lang = "uz"
        status_label = tr(customer_lang, f"status_{new_status}")
        try:
            await context.bot.send_message(
                int(row["user_id"]),
                tr(customer_lang, "status").format(order_id=order_id, status=status_label)
            )
        except Exception:
            logging.exception("Customer status notification failed")
        await query.edit_message_reply_markup(reply_markup=None)
        await query.message.reply_text(tr(lang, "status_updated"))
        return


async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    step = context.user_data.get("checkout_step")
    lang = lang_of(context)
    if not step:
        await update.message.reply_text(tr(lang, "menu"), reply_markup=menu_keyboard(lang))
        return
    value = (update.message.text or "").strip()
    data = context.user_data.setdefault("checkout", {})
    if step == "name":
        if len(value) < 2:
            await update.message.reply_text(tr(lang, "ask_name"))
            return
        data["name"] = value
        context.user_data["checkout_step"] = "phone"
        phone_keyboard = ReplyKeyboardMarkup(
            [[KeyboardButton("📱 Telefon raqamni yuborish", request_contact=True)]],
            resize_keyboard=True, one_time_keyboard=True
        )
        await update.message.reply_text(tr(lang, "ask_phone"), reply_markup=phone_keyboard)
    elif step == "phone":
        contact = update.message.contact
        phone = contact.phone_number if contact else value
        if len(phone) < 5:
            await update.message.reply_text(tr(lang, "ask_phone"))
            return
        data["phone"] = phone
        context.user_data["checkout_step"] = "address"
        await update.message.reply_text(
            tr(lang, "ask_address"),
            reply_markup=ReplyKeyboardMarkup([["❌ /cancel"]], resize_keyboard=True)
        )
    elif step == "address":
        if len(value) < 5:
            await update.message.reply_text(tr(lang, "ask_address"))
            return
        data["address"] = value
        context.user_data["checkout_step"] = "payment"
        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton(tr(lang, "cash"), callback_data="payment:cash"),
            InlineKeyboardButton(tr(lang, "card"), callback_data="payment:card")
        ]])
        await update.message.reply_text(tr(lang, "ask_payment"), reply_markup=keyboard)


async def orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lang = lang_of(context)
    if not is_admin(update.effective_user.id):
        await update.message.reply_text(tr(lang, "not_admin"))
        return
    with db() as conn:
        rows = conn.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 10").fetchall()
    if not rows:
        await update.message.reply_text(tr(lang, "no_orders"))
        return
    lines = [tr(lang, "orders_title")]
    for row in rows:
        status = tr(lang, f"status_{row['status']}")
        lines.append(f"#{row['id']} · {row['customer_name']} · {money(row['total'])} · {status}")
    await update.message.reply_text("\n".join(lines))


def main():
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN environment variable is missing.")
    init_db()
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("cancel", cancel))
    app.add_handler(CommandHandler("orders", orders))
    app.add_handler(CallbackQueryHandler(callback_handler))
    app.add_handler(MessageHandler(filters.TEXT | filters.CONTACT, text_handler))
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
